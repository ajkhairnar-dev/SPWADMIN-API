const p = require('q');

const getAll = (reqBody) => {
    let deferred = p.defer()
    let q = Query.addMaterial(reqBody)
    dbQuery.select(q).then(function (result) {
        let data = JSON.parse(result[0].fn_crudmaterial)
        deferred.resolve(data)
    }).catch(function(error){
        deferred.reject(error)
    })
    return deferred.promise
}


const doValidate = () =>{

    

}

const material = (req,res) => {
    validateRequest(reqBody).then(function(reqBody){

    }).then(function(data){
        return getAll(reqBody)
    }).then(function(data){
        return res.send(data)
    }).catch(function (error) {
        console.log(error)
        return res.status(200).send(error.toString())
    })
}


module.exports = {
    crudmaterial:material
}