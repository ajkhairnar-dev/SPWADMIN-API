CREATE OR REPLACE FUNCTION public.fn_crudmaterial(mid integer, mname text, mslug text, micon text, misactive integer, commandtype text)
 RETURNS text
 LANGUAGE plpgsql
AS $function$
 declare sp_resp text = null;
 declare list text = null;
	begin 
		if(lower(commandtype) = 'insert') then 
			if not exists(select g."slug" from "mst_material" g where g."slug" = LOWER(mslug)) then 
				
				insert into mst_material("name","slug","icon","isactive","createdate") values(mname,mslug,micon,misactive,now());
				
				sp_resp := '{"status": "success", "message": "Material inserted successfully", "data": {},"error": [] }';
			else 
				sp_resp := '{ 	"status": "success", "message": "Material already exists", "data": {},
								"error": [{"code": "ERR_056", "message": ["Material already exists"]}]
							}';
			end if;
		end if;
		
		if(lower(commandtype) = 'update') then
			update mst_material set "name" = mname, "slug" = mslug, "icon" = micon where "Id" = mid;
			sp_resp := '{"status": "success", "message": "Material updated successfully", "data": {},"error": [] }';
		end if;
	
		if(lower(commandtype)='list') then 
			list := (SELECT array_to_json(array_agg(row)) FROM (
						select * from mst_material)row);
					
			sp_resp := '{"status": "success","message":"Record found","error": [],"data":{"list":' ||coalesce(list, '[]')||'}' ||'}';
		
		end if;
	
		return sp_resp;
	end;
$function$
;
