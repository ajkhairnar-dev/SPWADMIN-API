require('dotenv').config()
const express = require("express")
const cors = require("cors")
const moment = require('moment');
const app = express()
global.consts=require('./src/config/consts')
global.conn = require("./src/config/dbconnection");
global._ = require('underscore');
global.q = require('q');
global.basepath='/v1/admin';
app.use(cors())
app.use(express.json());

const { verifyApiKey} = require('./src/common/verifyapikey')
const auth = require("./src/route/auth.route")
// const material = require('./src/route/material.route')

const mainRoute = require('./src/route/routeFile')
// app.use(verifyApiKey)
app.use(auth)

// app.use(material)
app.use(mainRoute)

app.get('*', function(req, res){
    return res.status(400).send("Authentication failed.")
});

app.listen(process.env.PORT || consts.port, () => console.log(`server run on Port :${consts.port}!`))
