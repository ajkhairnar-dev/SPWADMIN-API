const verifyApiKey = async(req,res,next) => {
    const apikey = req.headers['apikey'] ? req.headers['apikey'] : null;
    console.log(apikey)
    if(apikey==null || apikey == undefined || apikey=="" || apikey !== consts.apikey){
        return res.status(401).send({ success:false,message:"Authentication Fail.", errorCode:{},data:{}})
    }
    next()
}

module.exports = {
    verifyApiKey
}