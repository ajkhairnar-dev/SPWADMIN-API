module.exports = {
    defaultURL:"/v1/api",
    port:3300,               // -------- for vendor panel
    apikey:"8xas/sRrL3%UbT_A",
    localUrl:"http://localhost:3000",
    serverUrl:"",
    timezone: 'Asia/Kolkata',
    addUserTimeZone: 'India Standard Time',
    dateFormat: 'YYYY-MM-DD',
    timeFormat: 'hh:mm',
    currency: 'INR'
}