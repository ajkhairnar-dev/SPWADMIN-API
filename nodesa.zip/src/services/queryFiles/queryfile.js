

module.exports = {

    getMaterial : function(){
        return `select * from fn_getallmaterial()`;
    },

    addMaterial : function(reqBody){
        return `select * from fn_insertmaterial(
            mid:=${reqBody.id},
            mname:='${reqBody.name}',
            mslug:='${reqBody.slug}',
            micon:='${reqBody.micon}',
            misactive:=${reqBody.misactive},
            commandtype:='${reqBody.commandtype}'
        )`
    }
}