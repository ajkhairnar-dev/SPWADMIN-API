const express = require('express');
const consts = require('../config/consts');
const auth = express.Router()
const { login } = require('../controller/auth/login.controller')
const { registration,otprevification } = require('../controller/auth/registration.controller')
const {loginValidation, } = require('../schema/auth/login.validation');

//-------- login -----------
auth.post(consts.defaultURL+'/login',loginValidation, login)


//----------- registration ---------
auth.post(consts.defaultURL+'/registration',registration)
auth.post(consts.defaultURL+'/otprevification',otprevification)

module.exports = auth

