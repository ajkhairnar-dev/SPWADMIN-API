const express = require('express')
const material = express.Router()


//---- material-------
material.get(basepath+'/getmaterial',require('../controller/material/material').getMeterial)
// material.post(basepath+'/addmaterial',addmaterialValidation,addMaterial)
// material.post(basepath+'/editmaterial',editmaterialValidation,editMaterial)
// material.post(basepath+'/deletematerial',deletematerialValidation,deleteMaterial)
// material.post(basepath+'/changematerialstatus',changematerialstatusValidation,changeMaterialStatus)


//------materiarate-----
// material.post(basepath+'/addmaterialrate',addMaterialRate)
// material.get(basepath+'/getmaterialrate',getMaterialsRate)
// material.post(basepath+'/changestatusmaterialrate',changeStatusMaterialRate)




module.exports = material

