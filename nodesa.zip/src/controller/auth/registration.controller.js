const {generateAccessToken} = require('../../common/jsonwebtoken');
const moment = require('moment');
const conn = require('../../config/dbconnection');

const registration = async(req,res) =>{
    const { mobileno } = req.body;
    try{
        let uniqueid = generateuniqueid()

        let result = await conn.query("select * from vendor_registration_logs where mobileno=$1",[mobileno]);
        if(_.isEmpty(result.rows))
        {
            // otp sent and create new row
            const {rows} = await conn.query("insert into vendor_registration_logs(mobileno,uniqueid,createat,isregistered,smscounter) values($1,$2,$3,$4,$5) RETURNING *",
            [mobileno,uniqueid,moment().format("YYYY-MM-DD hh:mm:ss"),0,0])
            let obj = {
                mobileno:rows[0].mobileno,
                uniqueid:rows[0].uniqueid
            }
            return res.status(200).send({ success:true,message:"OTP sent on your mobile",data:obj })
        }else{
            if(result.rows[0].isregistered == 0){
                // otp sent and update row
                let smssentcounter =  result.rows[0].smscounter + 1;
                const {rows} = await conn.query("update vendor_registration_logs set uniqueid=$1,createat=$2,isregistered=$3,smscounter=$4 where mobileno=$5 RETURNING *",
                [uniqueid,moment().format("YYYY-MM-DD hh:mm:ss"),0,smssentcounter,mobileno])

                let obj = {
                    mobileno:rows[0].mobileno,
                    uniqueid:rows[0].uniqueid
                }
                return res.status(200).send({ success:true,message:"OTP sent on your mobile",data:obj })

            }else if(result.rows[0].isregistered == 1){
                return res.status(400).send({ success:false,message:"Mobile No. already registered.",data:{} })
            }else{
                return res.status(400).send({ success:false,message:"Something Wents wrong.",data:{} })
            }
        }
    }catch(error){
        return res.status(400).send({success:false, data:{ error:error } })
    }
}

const otprevification = async(req,res) =>{
    const { mobileno,uniqueid } = req.body;
    let result = await conn.query("select * from vendor_registration_logs where mobileno=$1 and uniqueid=$2",[mobileno,uniqueid])
    if(_.isElement(result.rows))
    {
        return res.status(400).send({ success:false,message:"Something Wents wrong. Please try again.",data:{} })
    }else{
       await conn.query("insert into mst_vendor(mobileno,)")
    }
}


let generateuniqueid = function () {
    let text = ''
    let possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    // File_02Feb2017_105115180_0bc0984c71784fc78a26ba2ab278f5ab.png
    for (let i = 0; i < 30; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length))
    }
    let fileName = 'uid' + '_' + moment(new Date()).format('DDMMMYYYY') + '_' + Date.now() + '_' + text
    return fileName
  }


module.exports = {
    registration,otprevification
}