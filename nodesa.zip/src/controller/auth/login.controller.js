const {generateAccessToken} = require('../../common/jsonwebtoken');
const bcrypt = require('bcryptjs');
const ecode = require("./error_code.json");
//$2a$10$/ceTpSqViEsRuD2vXT/BRe0Yl2VPNtx0P4kfWiHOoHhWbWK3G7wPS
//123456

const login = async (req,res) => {
    const { emailid,password } = req.body;
    try{
        const {rows} = await conn.query("select vendor_id, firstname,lastname,emailid, mobileno, password,isblocked,isverified from mst_vendor where emailid=$1",[emailid]);
        if(_.isEmpty(rows)){
            return res.status(401).send({ success:false,message:ecode.SYSA0104.msg,errorCode:ecode.SYSA0104.code, data:{} })
        }
        //password verify
        const bpass = await bcrypt.compare(password,rows[0].password);
        if(!bpass){ 
            return res.status(400).send({ success:false,message:ecode.SYSA0105.msg,errorCode:ecode.SYSA0105.code, data:{} })
        }
        //check Conditions -  isblock, isverify
        const isWrong= checkConditions(rows);
        if(isWrong){ return res.status(400).send(isWrong) }

        const data = _.omit(rows[0],'password','isblocked','isverified');
        //generate jwt token
        const token = await generateAccessToken(data);
        res.status(200).send({ success:true,message:"Login successfully.", data:{user:data,token:token} })
    }catch (error) {
        return res.status(400).send({success:false, data:{ error:error } })
    }
}

const checkConditions = (rows) => {
    if(rows[0].isblocked == 1){ //isblock
        return { success:false,message:ecode.SYSA0101.msg,errorCode:ecode.SYSA0101.code, data:{} }
    }else if(rows[0].isverified == 0){ //isverify
        return { success:false,message:ecode.SYSA0102.msg,errorCode:ecode.SYSA0102.code, data:{} }
    }
}

module.exports = {
    login
}