const Query = require('../../services/queryFiles/queryfile')
const getMeterial = async (req,res) => {
    try{
   
        let reqBody = {
            id : 1,
            name:"Pk1",
            slug:"pk111",
            micon:"pkerewrwer.png",
            misactive:1,
            commandtype:'insert'
        }

       let q = Query.addMaterial(reqBody)

       // let q = `select * from fn_insertmaterial(${reqBody.id},'${reqBody.name}','${reqBody.slug}','${reqBody.micon}',${reqBody.misactive},'${reqBody.commandtype}')`

        const {rows} = await conn.query(q);
        // let staticFile = '/material/static.png'
        // console.log(rows)
        // rows.forEach(obj => obj.materialicon = obj.materialicon ? s3FilereadStaticURL(obj.materialicon) : s3FilereadStaticURL(staticFile));
        // if(_.isEmpty(rows)){
        //     return res.status(200).send({ success:true,message:"Material Not Found.",data:{material:rows}})
        // }
        res.status(200).send(rows)
    }catch (error) {
        return res.status(400).send(error)
    }
}


module.exports = {
    getMeterial
}

// const response ={"success":true,"message":[{"fn_insertmaterial":"{ \t\"status\": \"success\", \"message\": \"Material already exists\", \"data\": {},\r\n\t\t\t\t\t\t\t\t\"error\": [{\"code\": \"ERR_056\", \"message\": [\"Material already exists\"]}]\r\n\t\t\t\t\t\t\t}"}]}


// let data = JSON.parse(response.message[0].fn_insertmaterial)

// console.log(data.error)