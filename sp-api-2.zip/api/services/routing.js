const express = require('express');
const route = express.Router()


route.get('/material',require('../controllers/material/material').crudmaterial)


module.exports = route