const q = require('q')
const fs = require('fs')
const json2xls = require('json2xls')
const moment = require('moment')
const _ = require('underscore')

let self = module.exports = {

  // below function is used to generate proper request parameter while hitting PostGreSQL function
  getPostGreParam: function (paramValue, paramType) {
    let paramIsArray = _.isArray(paramValue)

    if (paramIsArray && paramType.toLowerCase() === 'arrayofstring') {
      let paramString = ''
      _.each(paramValue, function (pElement) {
        if (_.isEmpty(paramString)) {
          paramString = "'" + pElement + "'"
        } else {
          paramString = paramString + ",'" + pElement + "'"
        }
      })
      paramValue = paramString
    } else if (paramIsArray && paramType.toLowerCase() === 'arrayofint') {
      let param = []
      _.each(paramValue, function(element) {
        param.push(element)
      })
      paramValue = param
    }
    
    paramType = _.isEmpty(paramType) ? '' : paramType.toString()
    let retVal = null
    switch (paramType.toLowerCase()) {
      case 'string':
        retVal = _.isEmpty(paramValue) ? null : "'" + paramValue.replace(/'/g, "''") + "'"
        break
      case 'arrayofstring':
        retVal = _.isEmpty(paramValue) ? null : paramValue
        break
      case 'arrayofint':
        retVal = _.isEmpty(paramValue) ? null : paramValue
      case 'boolean':
        retVal = paramValue || false
        break
      case 'int':
      default:
        retVal = paramValue || null
        break
    }
    return retVal
  },

  //generate new Excel file
  getGenerateExcel: function (jsonData, filePath) {
    self = this
    let updatedExcelFile = json2xls(jsonData)
    //checking file exist or not
    fs.stat(filePath, function (err, stat) {
      if (err) {
        return console.error(err)
      }
    })
    //generate excle file code
    fs.writeFileSync(filePath, updatedExcelFile, 'binary')
    return filePath
  },

  //common validation error response
  validationError:function(){
    let response={}
    response.status = 'fail'
    response.message = 'Error generated'
    response.error = ['Invalid action']
    response.data = []
    return response
  }


};