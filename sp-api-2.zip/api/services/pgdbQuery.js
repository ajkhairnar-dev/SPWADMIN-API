let pg = require('pg')
let config = require('../config/db.json')
const q = require('q')
let pool = new pg.Pool(config)

/* Get data from postgresql server */
function select (qry) {
  let deferred = q.defer()
  if (qry === null) {
    return deferred.reject('No Query Found')
  } else {
    pool.connect()
      .then(client => {
        client.query(qry)
          .then(res => {
            client.release()
            // client.end()
            deferred.resolve(res.rows)
          })
          .catch(e => {
            client.release()
            deferred.reject({
              code: 200,
              error: e.message.toString()
            })
          })
      })
      .catch(e => {
        console.error('pgDBquery catch', e.message, e.stack)
        deferred.reject({
          code: 200,
          error: e.message.toString()
        })
      })
  }
  return deferred.promise
}

/* Insert data to postgresql server */
function insert (qry) {
  let deferred = q.defer()
  if (qry == null) {
    return deferred.reject('No Query Found')
  } else {
    pool.connect(function (err, client, done) {
      if (err) {
        return deferred.reject(err)
      } else {
        client.query(qry, function (err, result) {
          done()
          if (err) {
            return deferred.reject(err)
          } else {
            return deferred.resolve(result)
          }
        })
      }
    })
    pool.on('error', function (err, client) {
      return deferred.reject('idle client error', err.message, err.stack)
    })
  }
  return deferred.promise
}

exports.select = select
exports.insert = insert
