let jsonValidator = require('../jsonValidator/materialValidator').doValidate

const getAll = (reqBody) => {
    let deferred = q.defer()
    let query = Query.addMaterial(reqBody)
    dbQuery.select(query).then(function (result) {
        let data = JSON.parse(result[0].fn_crudmaterial)
        deferred.resolve(data)
    }).catch(function(error){
        deferred.reject(error)
    })
    return deferred.promise
}


const material = (req,res) => {
    let reqBody = {
        name:"Plastic",
        slug:"dfdsfsf",
        icon:"sdfsd",
        isactive:1,
        commandtype:"insert"
    }

    jsonValidator(reqBody).then(function(){
        return getAll(reqBody)
    }).then(function(data){
        return res.send(data)
    }).catch(function (error) {
        console.log(JSON.stringify(error))
        return res.status(200).send(error.toString())
    });
}


module.exports = {
    crudmaterial:material
}