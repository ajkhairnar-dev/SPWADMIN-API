let handlebars = require('handlebars')
const path = require('path')
const fs = require('fs');
let pdf = require('html-pdf')

// flow   -> create dynamic html file and store locally -> create html file to pdf

const createpdffile = (req,res)=>{

    let data = {
        "name":"Jayesh",
        "age":98
    }

    let templateFilePath = path.join(__dirname, './templates/invoice.html')
    fs.readFile(templateFilePath, 'utf-8', function (error, body) {
        if (error) {
          console.log(error)
        } else {
            let template = handlebars.compile(body)
            let result = template(data)

            fs.writeFile('dynamicfile.html', result, function (err) {
                if (err) {
                  console.log(err)
                } else {
                    
                    //  create html file to pdf
                    let options = {
                        format: 'Legal'
                      }
                      let htmlFullPath = 'dynamicfile.html';
                      let html = fs.readFileSync(htmlFullPath, 'utf8')
                      pdf.create(html, options).toFile('createpdf.pdf', function (err, res) {
                        if (err) {
                          console.log("error on creation pdf")
                        }else{
                            console.log("pdf created",res)
                        }
                        
                      })
                    //   ------------------------
                }
              })
        }
      })

}


module.exports = createpdffile