const { Parser } = require('json2csv');
const fs = require('fs')
const jsontocsv= ()=>{

    const myCars = [
        {
          "car": "Audi",
          "price": 40000,
          "color": "blue"
        }, {
          "car": "BMW",
          "price": 35000,
          "color": "black"
        }, {
          "car": "Porsche",
          "price": 60000,
          "color": "green"
        }
      ];
      
      const json2csvParser = new Parser();
      const csv = json2csvParser.parse(myCars);
      fs.writeFileSync('data.csv', csv, 'binary');
}

module.exports = jsontocsv


