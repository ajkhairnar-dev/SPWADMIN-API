let bwipjs = require('bwip-js')
const fs = require('fs');

const createbarcode = (req,res) =>{

    bwipjs.toBuffer({
        bcid: 'code128',
        text: '98989898',
        scale: 2,
        height: 4,
        width: 10,
        includetext: true,
        textxalign: 'center',
        textyalign:'above',
        textfont: 'Inconsolata',
        textsize: 2,
        barcolor: '000000',
        textcolor: '000000',
        backgroundcolor: 'FFFFFF'
      }, function (err, png) {
        if (err) {
          console.log(err)
        } else {

            fs.writeFile('dynamicfile.png', png, function (err) {
                    if(err){
                        console.log(err)
                    }else{
                        console.log(png)
                    }
            })

        //   response.data = png.toString('base64')
          
        
        }
      })

}

module.exports =createbarcode