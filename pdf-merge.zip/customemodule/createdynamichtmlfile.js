let handlebars = require('handlebars')
const path = require('path')
const fs = require('fs');

// flow   -> create dynamic html file and store locally

const dynamichtml = (req,res)=>{

    let data = {
        "name":"Jayesh",
        "age":98
    }

    let templateFilePath = path.join(__dirname, './templates/invoice.html')

    fs.readFile(templateFilePath, 'utf-8', function (error, body) {
        if (error) {
          console.log(error)
        } else {
            let template = handlebars.compile(body)
            let result = template(data)

            fs.writeFile('dynamicfile.html', result, function (err) {
                if (err) {
                  console.log(err)
                } else {
                  console.log('done')
                }
              })
        }
      })

}


module.exports = dynamichtml