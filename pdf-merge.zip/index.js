const express = require('express')
const PDFMERGE = require('easy-pdf-merge')
const path = require('path')
const app = express()

const port = 3000



app.get('/json2xml',require('./customemodule/json2xls'))    // json to xls
app.get('/json2csv',require('./customemodule/json2csv'))    // json to csv
app.get('/dynamichtml',require('./customemodule/createdynamichtmlfile')) // create dynamic html file
app.get('/dynamicpdf',require('./customemodule/createpdf'))   // create dynamic pdf
app.get('/barcode',require('./customemodule/createbarcode'))  //create barcode





// app.get('/merge', (req, res) => {
//  let f1 = path.join(__dirname,`./files/File_10Aug2022_1660119527727_urkC0gfmpFNDFW9fqzuJ4XF6JtLAof.pdf`)
//  let f2 = path.join(__dirname,`./files/File_10Aug2022_1660119527727_urkC0gfmpFNDFW9fqzuJ4XF6JtLAof123.pdf`)
//  let newfile= path.join(__dirname,`./mergefiles/new1234.pdf`)
// console.log(f1)
// console.log(f2)
//  PDFMERGE([
//     f1,
//     f2
//   ],
//   newfile,(err) => {
//     if (err) {
//       console.log(err)
//     }
//     console.log(newfile)
//   })
// }); 






app.listen(port, () => {
  console.log(port)
})
