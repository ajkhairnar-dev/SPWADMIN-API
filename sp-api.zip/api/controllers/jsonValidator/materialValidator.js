let Validator = require('jsonschema').Validator

module.exports = {
    doValidate :function(reqBody){
        let deffered = q.defer()
        let v = new Validator()
        let response = {}
        let error = []
        let result = null

        if (!_.isEmpty(reqBody.commandtype)) {
            let mainSchema = {}
            // write schema for validation
            switch (reqBody.commandtype) {
                case 'list':
                    mainSchema= {
                        id: '/mainSchema',
                        type: 'object',
                        properties: {
                            commandtype: {
                                'type': ['string'],
                                'required': true
                            }
                        }
                    }
                    break; 

                case 'insert':
                    mainSchema= {
                        id: '/mainSchema',
                        type: 'object',
                        properties: {
                            name: {
                                'type': ['string'],
                                'minLength': 1,
                                'required': true
                            },
                            slug:{
                                'type': ['string'],
                                'required':true
                            },
                            icon:{
                                type: ['string'],
                                'required':true
                            },
                            isactive:{
                                'type': ['integer'],
                                'required':true
                            },
                            commandtype:{
                                'type': ['string'],
                                'required':true
                            }
                        }
                    }
                    break
                default:
                    deffered.reject(cmfun.validationError())
                    break;
            }
            //validate schema
            result = v.validate(reqBody, mainSchema)
        }else{
            deffered.reject(cmfun.validationError())
        }

        // Generate final response
        if (!_.isEmpty(result)) {
          if (result.valid) {
            response.status = 'success'
            response.message = 'Validation done successfully'
            response.data = reqBody
            deffered.resolve(response)
          } else {
            error = _.map(_.pluck(result.errors, 'stack'), function (err) {
              return err.replace(/instance./, '')
            })
            response.status = 'fail'
            response.message = 'Error generated'
            response.error = [{
              'code': 'ERR_0011',
              'message': error
            }]
            response.data = {}
            deffered.reject(response)
          }
        }
        return deffered.promise
    }

}
