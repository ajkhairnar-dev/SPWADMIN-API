let commonFunctions = require('../services/commonFunction');

module.exports = {

    addMaterial : function(reqBody){
        return `select * from fn_crudmaterial(
            mid:=${commonFunctions.getPostGreParam(reqBody.id,'int')},
            mname:=${commonFunctions.getPostGreParam(reqBody.name,'string')},
            mslug:=${commonFunctions.getPostGreParam(reqBody.slug,'string')},
            micon:=${commonFunctions.getPostGreParam(reqBody.micon,'string')},
            misactive:=${commonFunctions.getPostGreParam(reqBody.misactive,'int')},
            commandtype:=${commonFunctions.getPostGreParam(reqBody.commandtype,'string')}
        )`;
    }

}