require('dotenv').config()
const express = require("express")
const cors = require("cors")
const app = express()
global._ = require('underscore');
global.q = require('q');
global.dbQuery = require('./api/services/pgdbQuery')
global.Query = require('./api/services/queryFile')
global.cmfun = require('./api/services/commonFunction')
app.use(cors())
app.use(express.json());

const router = require("./api/services/routing")

app.use(router)

app.get('*', function(req, res){
    return res.status(400).send("Authentication failed.")
});

app.listen(8000, () => console.log(`server run on Port :${8000}`))
