require('dotenv').config()
const express = require("express")
const cors = require("cors")
const moment = require('moment');
const app = express()
global._ = require('underscore');
global.q = require('q');

app.use(cors())
app.use(express.json());



app.get('*', function(req, res){
    return res.status(400).send("Authentication failed.")
});

app.listen(8000, () => console.log(`server run on Port :${8000}`))
